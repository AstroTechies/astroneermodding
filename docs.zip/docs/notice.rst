.. note::

   This site is not affiliated with System Era in any way and is exclusively community-run.
   Also Astroneer has no official mod support and everything is community-built.